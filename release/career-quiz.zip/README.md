# Career Quiz
Create and display career quiz questions

## Changelog
~Current Version:1.1.0~

### 1.1.0
* Added Plugin update feature

### 1.0.0
* Plugin created